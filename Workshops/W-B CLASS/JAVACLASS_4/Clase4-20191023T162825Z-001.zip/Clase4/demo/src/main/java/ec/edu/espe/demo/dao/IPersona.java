package ec.edu.espe.demo.dao;

public interface IPersona{

    public String sayHello();
}