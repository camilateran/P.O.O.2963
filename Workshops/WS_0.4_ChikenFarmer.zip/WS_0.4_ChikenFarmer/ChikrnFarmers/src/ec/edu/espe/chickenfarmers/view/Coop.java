
package ec.edu.espe.chickenfarmers.view;

/**
 *
 * @author DTj
 */
public class Coop {
    private int id;
    private Chicken[] chicken;
    
public void add(Chicken chicken){
    
}
public void remove(int chickenld){
    
}
public void resetlteration(){
    
}
public Chicken next(){
    return new Chicken();
}
}
