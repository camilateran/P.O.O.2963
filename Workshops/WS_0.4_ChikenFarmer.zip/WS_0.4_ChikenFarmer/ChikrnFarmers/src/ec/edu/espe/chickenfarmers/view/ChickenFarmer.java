
package ec.edu.espe.chickenfarmers.view;

/**
 *
 * @author DTj
 */
public class ChickenFarmer {
    private String name;
    private Coop[] coop;
    
public void add(Coop coop){
    
}
public void remove (int coopld){
    
}
public void resetlteration(){
    
}
public Coop next(){
    return new Coop();
}
}
