
package ec.edu.espe.chickenfarmers.view;

/**
 *
 * @author DTj
 */
public class Egg {
    private int id;
    
}
